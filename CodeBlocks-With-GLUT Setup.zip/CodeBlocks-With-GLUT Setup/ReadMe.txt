
___________________________________________________________________________
		Code::Blocks Setup Installation with OpenGL  for Computer Graphics Programming 
`````````````````````````````````````````````````````````````````````````````````````````````````````````````````````

	Pre-request:  Download the full setup package (get Links in the description of this vedio)
	^^^^^^^^^
==> Tutorial Link: https://youtu.be/FbCDWkq14Ng
=> Refere Installation Steps in Description 